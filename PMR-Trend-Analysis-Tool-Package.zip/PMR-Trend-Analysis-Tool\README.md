# PMR Trend Analysis Tool
**IBM Expertise Connect — Support Ticket Trend Analysis**

---

## Quick Start (3 steps)

**Step 1** — Unzip this package anywhere on your laptop

**Step 2** — Open `ticket-trend-analysis-tool.html` in **Chrome or Edge** (right-click → Open with → Chrome)

**Step 3** — Click **Browse File**, select your Excel export → full report generates instantly

> No installation. No internet required. No data leaves your machine.

---

## What's in This Package

```
PMR-Trend-Analysis-Tool\
├── ticket-trend-analysis-tool.html        ← Open this in Chrome / Edge
├── README.md                              ← This file
└── sample-data\
    └── DB Bank - Analysis-...xlsx         ← Real test file (9 tickets, Deutsche Bank AG)
```

**To test immediately:** Upload the file in `sample-data\` — it will generate a full Deutsche Bank AG PMR trend report with charts, KPIs, and recommendations.

---

## What the Tool Does

Upload any Salesforce (or ServiceNow / Jira / custom) case export Excel or CSV file. The tool:

| Feature | Detail |
|---|---|
| Auto-detects columns | Works with any column names, any order, any extra columns |
| Account Name highlighted | Reads `Account Name` from your file and highlights it in blue throughout the report |
| Monthly volume trend | Bar chart: tickets created / closed / open backlog per month |
| Backlog trend | Line chart showing end-of-month open backlog over time |
| Severity breakdown | Sev 1 / 2 / 3 / 4 — created, resolved, open counts and charts |
| Closure rate | Per month and overall — highlights best and worst months |
| Average resolution time | By severity, in days |
| Ticket detail cards | Subject, issue summary, resolution text, owner, dates |
| Recommendations | 5 auto-generated action items based on your data |
| PDF export | Click **Save as PDF** or press `Ctrl+P` |

---

## How to Get Your Export from Salesforce

1. In Salesforce, go to **Reports**
2. Open or create a report of type **Cases** or **Accounts with Cases**
3. Make sure these columns are included *(minimum required)*:
   - `Case Number`
   - `Date/Time Opened` *(or `Opened Date`)*
   - `Subject`
   - `Status`
   - `Severity Level` *(or `Priority`)*
   - `Account Name`
4. Add these for a richer report *(optional but recommended)*:
   - `Date/Time Closed`
   - `Resolution Description` *(or `About the Issue and Resolution`)*
   - `Case Owner`
   - `Created By`
   - `Account CMR Number`
   - `Escalated`
   - `Time to Close`
5. Click **Export** → choose **Excel (.xlsx)**
6. Open the tool and upload the downloaded file

---

## Supported Column Name Variants

The tool recognises all of these automatically — no manual mapping needed:

| What you need | Column names that work |
|---|---|
| Case number | `Case Number`, `Ticket ID`, `Ticket`, `Incident Number`, `PMR`, `Case` |
| Open date | `Date/Time Opened`, `Opened Date`, `Created Date`, `Open Date`, `Start Date` |
| Close date | `Date/Time Closed`, `Closed Date`, `Resolved Date`, `Completion Date` |
| Subject | `Subject`, `Title`, `Summary`, `Issue`, `Description`, `Problem` |
| Status | `Status`, `Case Status`, `State` |
| Severity | `Severity Level`, `Severity`, `Priority`, `Impact`, `Urgency` |
| Account name | `Account Name`, `Customer Name`, `Client Name`, `Company Name` |
| Resolution | `Resolution Description`, `About the Issue and Resolution`, `Resolution Notes`, `Actions`, `Notes` |
| Owner | `Case Owner`, `Assigned To`, `Assignee`, `Engineer`, `Responsibility` |
| Product | `Support Mission`, `Product`, `Platform`, `Component`, `Version` |
| Escalated | `Escalated`, `Is Escalated` |
| Resolution time | `Time to Close`, `Days to Close`, `Duration`, `ETA` |

---

## How Closed Tickets Are Detected

A ticket is counted as **closed** if any of these are true:
- The `Date/Time Closed` column has a value, **OR**
- The `Status` value contains: `close`, `resolved`, `archived`, `done`, or `complete`

---

## Troubleshooting

| Problem | What to do |
|---|---|
| Tool opens but nothing happens after upload | Make sure you are using Chrome or Edge (not Internet Explorer or old Edge) |
| `Could not detect ticket data in this file` | Your file's column headers are not recognised. Check they match the list above. |
| `No valid ticket rows found` | Headers found but no data. Make sure the sheet has actual ticket rows below the header. |
| Wrong account name showing | Rename your column to exactly `Account Name` — do not use just `Account` (conflicts with `Account CMR Number`) |
| Report shows old data after re-upload | Press `Ctrl+Shift+R` to hard-reload the tool, then upload again |
| Wrong sheet is being read | The tool picks the sheet with the most recognised columns. Rename your data sheet to `Sheet1` or delete other sheets |
| Charts not showing | Make sure JavaScript is enabled in your browser. Try Chrome if using another browser |

---

## Integration with a Health Check Tool

If you want to link this tool alongside a health check HTML report:

**Option 1 — Add a link in the health check report (no coding needed):**
Put both HTML files in the same folder, then add this line anywhere in your health check HTML:
```html
<a href="ticket-trend-analysis-tool.html" target="_blank">Open PMR Trend Analysis</a>
```

**Option 2 — Single tabbed dashboard:**
Both tools can be combined into one `index.html` with tabs — "Health Check" and "PMR Trends". Request this from the tool author.

**Option 3 — Auto-fill account name from health check:**
Add `?account=AccountName` to the URL when opening the tool. The tool can be extended to read this and pre-highlight the account. Request this from the tool author.

---

## Technical Notes

| | |
|---|---|
| **Runs on** | Any laptop — Windows, Mac, Linux |
| **Browser** | Chrome 90+, Edge 90+, Firefox 88+ (not Internet Explorer) |
| **Internet required** | No — fully offline. The Excel parsing library is embedded inside the HTML file |
| **Data privacy** | All processing happens locally in your browser. Nothing is uploaded or sent anywhere |
| **File size** | ~900 KB (includes the embedded Excel parser) |
| **Dependencies** | None — single HTML file, no install, no Node.js, no Python |

---

## Version & Contact

| | |
|---|---|
| **Tool name** | PMR Trend Analysis Tool |
| **Built by** | IBM Expertise Connect (Sreekanth Rajan) |
| **Version** | September 2026 |
| **Tested with** | Deutsche Bank AG (9 tickets), Amdocs, ServiceNow/Jira exports |
| **Contact** | Sreekanth Rajan — IBM Expertise Connect |
